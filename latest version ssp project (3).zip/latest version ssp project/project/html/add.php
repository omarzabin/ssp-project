<!DOCTYPE HTML>
<html>
	<head>
		<title>PSUT GYM</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/main.css" />
	
	</head>
	<body>

		<!-- Header -->
		<header id="header">
			<div class="inner">
				<a href="index.html" class="logo">PSUT GTM</a>
				<nav id="nav">
					<a  href="index.html">Home</a>
					<a style="background-color: white; color: black" href="#">Register</a>
					<a href="contact.html">Contact Us</a>
					<a href="adminlogin.html">Admin</a>
			
				</nav>
			</div>
		</header>
			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>


		
	<section id="main">
				<div class="inner">

<section style="background-image: url(../images/bgg.jpg); background-size: cover; "  >
<a href="../html/register.html"><input class="special" type="button" name="back" value="Back"></a>
<section id="main">
	
				<div class="inner">

<section>

		<h1 style="color:white;">Join Us Champ</h1>
		<form style="color:white;" method="post" action="../php/add.php" onSubmit="return validateForm();">
 <?php

         $hostname="localhost";
         $database_name="id17771110_project";
         $username="id17771110_project_user";
         $password="mQEipiXr91~>!IOb";


             $conn = mysqli_connect($hostname, $username, $password, $database_name);

             if(!$conn)
             {
                die("Database Connection Failed: " . mysqli_error($conn) );
             }
              $sql = "SELECT * FROM Plan ";
              $result = mysqli_query($conn, $sql);
             
             if ($result->num_rows > 0) {

?>
<div style=" padding-bottom: 18px;">First name<span style="color: red;"> *</span><br/>
<input style="border-color: white" type="text" id="data_2" name="data_2" style="width: 450px;" class="form-control"/>
</div>
<div style="padding-bottom: 18px;">Last name<span style="color: red;"> *</span><br/>
<input style="border-color: white" type="text" id="data_3" name="data_3" style="width: 450px;" class="form-control"/>
</div>
<div style="padding-bottom: 18px;">Phone<span style="color: red;"> *</span><br/>
<input style="border-color: white" type="text" id="data_4" name="data_4" style="width : 450px;" class="form-control"/>
</div>
<div style="padding-bottom: 18px;">Email<span style="color: red;"> *</span><br/>
<input style="border-color: white" type="text" id="data_5" name="data_5" style="width : 450px;" class="form-control"/>
</div>

<div style="padding-bottom: 18px;">Select Plan<span style="color: red;"> *</span><br/>

	<select >
 
 <option style="color:black">---Select Plan---</option>
 
 					<?php 
                        while($row = $result->fetch_assoc()) 
            
                	{
                	  
                	 ?>
 
<option  style="color:black;"> <?php echo "plan number ".$row["planId"]." : ".$row["monthNum"] ?> </option>

<?php } }?> 
</select>


<div style="padding-bottom: 18px;">Start date<span style="color: red;"> *</span><br/>
<input style="border-color: white;" type="date" id="data_6" name="data_6" style="width : 450px;" class="form-control"/>
</div>
<script type="text/javascript">new Pikaday({ field: document.getElementById('data_6') });</script>


<div style="padding-bottom: 18px;"><input name="Submit" class="special" value="Submit" type="submit"/></div>
<div>

</div>
</form>
</section>
</div>
</section>
</section>
</div>
</section>

<script type="text/javascript">
function validateForm() {
if (isEmpty(document.getElementById('data_2').value.trim())) {
alert('First name is required!');
return false;
}
if (isEmpty(document.getElementById('data_3').value.trim())) {
alert('Last name is required!');
return false;
}
if (isEmpty(document.getElementById('data_4').value.trim())) {
alert('Phone is required!');
return false;
}
if (isEmpty(document.getElementById('data_5').value.trim())) {
alert('Email is required!');
return false;
}
if (!validateEmail(document.getElementById('data_5').value.trim())) {
alert('Email must be a valid email address!');
return false;
}
if (isEmpty(document.getElementById('data_6').value.trim())) {
alert('Start date is required!');
return false;
}
return true;
}
function isEmpty(str) { return (str.length === 0 || !str.trim()); }
function validateEmail(email) {
var re = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,15}(?:\.[a-z]{2})?)$/i;
return isEmpty(email) || re.test(email);
}
</script>


		

		

	<!-- Footer -->
			<section id="footer">
				<div class="inner">
					<header>
						<h2>Get in Touch</h2>
					</header>
					
					<h5>JOIN US ON</h5>
					<a href="https://twitter.com/home" target="_blank"><img src="../images/twitter.jpg" width="50px"> </a>
					<a href="https://web.facebook.com/" target="_blank"><img src="../images/fb.jpg" width="50px"> </a>
					<a href="https://www.instagram.com/"target="_blank"><img src="../images/insta.jpg" width="50px"> </a>
				</div>
			</section>
			<!-- Scripts -->
			<script src="js/jquery.min.js"></script>
			<script src="js/skel.min.js"></script>
			<script src="js/util.js"></script>
			<script src="js/main.js"></script>
			
	</body>
</html>