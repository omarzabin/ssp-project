<!DOCTYPE HTML>
<html>
	<head>
		
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/main.css" />
	
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="../html/index.html" class="logo">PSUT GYM</a>
					<nav id="nav">
						
						<a style="background-color: white; color: black" href="../html/admin_page.html">Admin</a>
					   
						<a href="logout.php">Logout</a>
						
					</nav>
				</div>
			</header>
			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>


		
	<section id="main">
				<div class="inner">

<a href="../html/admin_page.html"><input class="special" type="button" name="back" value="Back"></a>

<section id="main">
				<div class="inner">
<section>

							<h1>Update Subscriber Information </h1>
							 <?php

              $hostname="localhost";
              $database_name="id17771110_project";
              $username="id17771110_project_user";
              $password="mQEipiXr91~>!IOb";


             $conn = mysqli_connect($hostname, $username, $password, $database_name);

             if(!$conn)
             {
                die("Database Connection Failed: " . mysqli_error($conn) );
             }
            
                $id = $_GET['id'];
                $_SESSION["session_id"] =  $id;
                
                $sql = "SELECT * FROM Sbscribers WHERE ID = $id";
                $result = mysqli_query($conn, $sql);
            
                if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) 
                {
                	?>
                	
        		<form method="post" action="subscriberUpdatedDeleted.php">
                <div style=" padding-bottom: 18px;">ID<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['id']; ?>" id="data_2" name="data_2" style="width: 450px;" class="form-control" />
                </div>
                <div style="padding-bottom: 18px;">First name<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['firstName']; ?>" id="data_3" name="data_3" style="width: 450px;" class="form-control"/>
                </div>
                 <div style="padding-bottom: 18px;">Last name<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['lastName']; ?>" id="data_4" name="data_4" style="width: 450px;" class="form-control"/>
                </div>
                   
                <div style="padding-bottom: 18px;">Email<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['email']; ?>" id="data_5" name="data_5" style="width : 450px;" class="form-control"/>
                </div>
                  <div style="padding-bottom: 18px;">Phone<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo "0".$row['phone']; ?>" id="data_6" name="data_6" style="width : 450px;" class="form-control"/>
                </div>
                
                
                <div style="padding-bottom: 18px;">Strt Date<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['startDate']; ?>" id="data_7" name="data_7" style="width : 450px;" class="form-control"/>
                </div>
                <div style="padding-bottom: 18px;">End Date<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['endDate']; ?>" id="data_8" name="data_8" style="width : 450px;" class="form-control"/>
                <div style="padding-bottom: 18px;">Plan number<span style="color: red;"> *</span><br/>
                <input style="border-color: black" type="text" value="<?php echo $row['planId']; ?>" id="data_9" name="data_9" style="width : 450px;" class="form-control"/>
                </div>
                </div>
                    <input type="submit" name="Edit" value="Update" class="button1">
                </form>

                <?php
        }
    }


?>

</section>
</div>
</section>
</section>
</div>
</section>


		

		

	<!-- Footer -->
			<section id="footer">
				<div class="inner">
					<header>
						<h2>Get in Touch</h2>
					</header>
					
					<h5>JOIN US ON</h5>
					<a href="https://twitter.com/home" target="_blank"><img src="../images/twitter.jpg" width="50px"> </a>
					<a href="https://web.facebook.com/" target="_blank"><img src="../images/fb.jpg" width="50px"> </a>
					<a href="https://www.instagram.com/"target="_blank"><img src="../images/insta.jpg" width="50px"> </a>
				</div>
			</section>
			<!-- Scripts -->
			<script src="../js/jquery.min.js"></script>
			<script src="../js/skel.min.js"></script>
			<script src="../js/util.js"></script>
			<script src="../js/main.js"></script>
			
	</body>
</html>