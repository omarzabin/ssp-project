<?php

  $hostname="localhost";
  $database_name="id17771110_project";
  $username="id17771110_project_user";
  $password="mQEipiXr91~>!IOb";


// Create connection
$conn =  mysqli_connect($hostname,  $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['Submit']))
{
     
     {
        $firstname=$_POST['data_2'];
        $lastname=$_POST['data_3'];
        $phone=$_POST['data_4'];
        $email=$_POST['data_5'];
        $startDate=$_POST['data_6'];
        $endDate= date('Y-m-d', strtotime($startDate. ' + 3 months'));
        // $pid=$_POST['op'];
        // if($pid == 1)
        //     $endDate= date('Y-m-d', strtotime($startDate. ' + 3 months'));
        // else if($pid == 2)
        //     $endDate= date('Y-m-d', strtotime($startDate. ' + 6 months'));
        // else if($pid == 3)
        //     $endDate= date('Y-m-d', strtotime($startDate. ' + 1 year'));
        
     }
   
    
   

     $sql = "INSERT INTO Sbscribers (firstName, lastName, phone, email, startDate, endDate) VALUES ('$firstname', '$lastname', '$phone','$email', '$startDate', '$endDate')";
        $result = mysqli_query($conn, $sql);

     if(!$result)
        {
        	 echo "failed";
            die("Query Failed: " .mysqli_error($conn) );
        }
        else
           ?>
                <script> alert('Sbscriber has been added.'); window.location.replace("../html/register.html"); </script>
            <?php             
   }

?>