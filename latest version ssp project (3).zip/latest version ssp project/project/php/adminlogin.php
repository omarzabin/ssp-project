<?php

  $hostname="localhost";
  $database_name="id17771110_project";
  $username="id17771110_project_user";
  $password="mQEipiXr91~>!IOb";


// Create connection
$conn =  mysqli_connect($hostname,  $username, $password, $database_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['submit']))
{
 
   $password=$_POST['password'];
   $email=$_POST['email'];
  
   
   

        $sql = "SELECT * FROM User WHERE email='$email' AND password='$password' ";
        $result = mysqli_query($conn, $sql);

     if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) 
        { 
          ?> <script> window.location.replace("../html/admin_page.html");</script>
        <?php
        
      }
}
      else 
      {
        ?> <script> alert("Wrong username or password. Please try again!"); window.location.replace("../html/adminlogin.html");</script>
        <?php
      }
}
?>