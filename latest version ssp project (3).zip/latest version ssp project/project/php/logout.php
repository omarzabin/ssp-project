<?php
	
	header('Location: ../html/adminlogin.html');

?>