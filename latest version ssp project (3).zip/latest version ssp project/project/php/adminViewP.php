<!DOCTYPE HTML>
<html>
	<head>
		<title>Display Plans</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="stylesheet" href="../css/main.css" />
	
	</head>
	<body>

		<!-- Header -->
			<header id="header">
				<div class="inner">
					<a href="../html/index.html" class="logo">PSUT GYM</a>
					<nav id="nav">
						
						<a style="background-color: white; color: black" href="../html/admin_page.html">Admin</a>
					   
						<a href="logout.php">Logout</a>
						
					</nav>
				</div>
			</header>
			<a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>


		
	<section id="main">
				<div class="inner">

<section style=" background-size: cover; "  >
<a href="../html/admin_page.html"><input class="special" type="button" name="back" value="Back"></a>

<section id="main">
	
				<div class="inner">

<section  >

							<h1>All Plans </h1>
							 <?php

                $hostname="localhost";
                $database_name="id17771110_project";
                $username="id17771110_project_user";
                $password="mQEipiXr91~>!IOb";




             $conn = mysqli_connect($hostname, $username, $password, $database_name);

             if(!$conn)
             {
                die("Database Connection Failed: " . mysqli_error($conn) );
             }

            
            

             $sql = "SELECT * FROM Plan";
             $result = mysqli_query($conn, $sql);
      
    echo '<table style="font-size: 14px" border="1"> 
                		<tr style="font-weight: bolder;">
                			<td>Plan ID</td>
                			<td>Number Of Monthes</td>
                		</tr>';

           if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) 
            
                	{
                	echo ' 	<tr>
                			<td>' .  $row['planId'] . '</td>
                			<td>' .  $row['monthNum'] . '</td>
                		
                			
                		</tr>';
                	}
                		
                	echo'</table>';
                	}
                	?>

</section>
</div>
</section>
</section>
</div>
</section>


		

		

	<!-- Footer -->
			<section id="footer">
				<div class="inner">
					<header>
						<h2>Get in Touch</h2>
					</header>
					
					<h5>JOIN US ON</h5>
					<a href="https://twitter.com/home" target="_blank"><img src="../images/twitter.jpg" width="50px"> </a>
					<a href="https://web.facebook.com/" target="_blank"><img src="../images/fb.jpg" width="50px"> </a>
					<a href="https://www.instagram.com/"target="_blank"><img src="../images/insta.jpg" width="50px"> </a>
				</div>
			</section>
			<!-- Scripts -->
			<script src="../js/jquery.min.js"></script>
			<script src="../js/skel.min.js"></script>
			<script src="../js/util.js"></script>
			<script src="../js/main.js"></script>
			
	</body>
</html>