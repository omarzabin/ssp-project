 <!DOCTYPE HTML>
<html>
    <head>
        <title>PSUT GYM</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="../css/main.css" />
    
    </head>
    <body>

        <!-- Header -->
         
            <a href="#menu" class="navPanelToggle"><span class="fa fa-bars"></span></a>


        
    <section id="main">
                <div class="inner">

<section style="background-image: url(images/bgg.jpg); background-size: cover; "  >
   
<?php

              $hostname="localhost";
              $database_name="id17771110_project";
              $username="id17771110_project_user";
              $password="mQEipiXr91~>!IOb";
           

            $conn = mysqli_connect($hostname, $username, $password, $database_name);

            if(!$conn)
            {
                die("Database Connection Failed: " . mysqli_error($conn) );
            }
            if (isset($_POST['Delete']))
            {
                 $id=$_POST['data_2'];
                $name=$_POST['data_3'];
                $email=$_POST['data_4'];
                
                $query  = "DELETE FROM User WHERE ID='$id'";
                $result = $conn->query($query);
                
              	if (!$result){ 
              	    echo "DELETE failed: $query<br>" .$conn->error . "<br><br>";
              	}
              	else{
                    ?>
                    <script> alert('Admen has been updated.'); window.location.replace("../html/admin_page.html"); </script>
                <?php 
              	}
            }    
            if(isset($_POST['Edit']))
            {
                
                $id=$_POST['data_2'];
                $name=$_POST['data_3'];
                $email=$_POST['data_4'];
                $pass=$_POST['data_5'];
                $query = "UPDATE User SET Name='$name', Email='$email', Password='$pass' WHERE ID='$id'";
                $result = mysqli_query($conn, $query);

                 if(!$result)
        {
             echo "failed";
            die("Query Failed: " .mysqli_error($conn) );
        }
        else
           ?>
                <script> alert('Information has been updated.'); window.location.replace("../html/admin_page.html"); </script>
            <?php 
            }
        ?>

</section>
</div>
</section>


    <!-- Footer -->
            <section id="footer">
                <div class="inner">
					<header>
						<h2>Get in Touch</h2>
					</header>
					
					<h5>JOIN US ON</h5>
					<a href="https://twitter.com/home" target="_blank"><img src="../images/twitter.jpg" width="50px"> </a>
					<a href="https://web.facebook.com/" target="_blank"><img src="../images/fb.jpg" width="50px"> </a>
					<a href="https://www.instagram.com/"target="_blank"><img src="../images/insta.jpg" width="50px"> </a>
				</div>
            </section>
            <!-- Scripts -->
            <script src="js/jquery.min.js"></script>
            <script src="js/skel.min.js"></script>
            <script src="js/util.js"></script>
            <script src="js/main.js"></script>
            
    </body>
</html>
